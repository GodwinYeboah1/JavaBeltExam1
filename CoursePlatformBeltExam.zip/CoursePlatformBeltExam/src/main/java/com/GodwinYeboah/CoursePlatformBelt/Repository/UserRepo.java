package com.GodwinYeboah.CoursePlatformBelt.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.GodwinYeboah.CoursePlatformBelt.Models.User;

@Repository
public interface UserRepo extends CrudRepository<User, Long> {
	User findByEmail(String email);
}
