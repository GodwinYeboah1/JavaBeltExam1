package com.GodwinYeboah.CoursePlatformBelt.Services;

import org.springframework.stereotype.Service;

import com.GodwinYeboah.CoursePlatformBelt.Models.Course;
import com.GodwinYeboah.CoursePlatformBelt.Models.User;
import com.GodwinYeboah.CoursePlatformBelt.Repository.CourseRepo;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;


@Service
public class CourseService {
    private CourseRepo courseRepo;
    private BCryptPasswordEncoder bcrypt; 
    public CourseService(CourseRepo courseRepo) {
        this.courseRepo = courseRepo;
        this.bcrypt = encoder();
    }
    public BCryptPasswordEncoder encoder() {
        return new BCryptPasswordEncoder();
    }
    public boolean isValid(HttpSession s) {
        if(s.getAttribute("id") == null) {
        		return false;
        	}
        else {
        		return true;
        	}
    }
    public Course create(Course course) {
        course.setInstructor(course.getInstructor());
        course.setName(course.getName());
        course.setSignuplimit(course.getSignuplimit());
        return this.courseRepo.save(course);
    }
    public ArrayList<Course> all(){
        return (ArrayList<Course>) this.courseRepo.findAll();
    }
    public Course find(long id) {
        return (Course) this.courseRepo.findById(id).orElse(null);
    }
    public void destroy(long id) {
        this.courseRepo.deleteById(id);
    }
    public void updateCourse(long id, Course course) {
        this.courseRepo.save(course);
    }
    public List<Course> sortASC(){
        return (List<Course>) this.sortASC();
    }

}	
	
	
	
