package com.GodwinYeboah.CoursePlatformBelt.Repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.GodwinYeboah.CoursePlatformBelt.Models.Course;
import com.GodwinYeboah.CoursePlatformBelt.Models.User;

@Repository
public interface  CourseRepo extends CrudRepository<Course, Long>{
//just created this and can be delete
	
	
}
