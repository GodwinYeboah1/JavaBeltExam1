package com.GodwinYeboah.CoursePlatformBelt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoursePlatformBeltExamApplication {

	public static void main(String[] args) {
		SpringApplication.run(CoursePlatformBeltExamApplication.class, args);
	}
}
