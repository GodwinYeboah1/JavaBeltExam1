package com.GodwinYeboah.CoursePlatformBelt.Controller;
import java.util.ArrayList;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.GodwinYeboah.CoursePlatformBelt.Models.Course;
import com.GodwinYeboah.CoursePlatformBelt.Models.User;
import com.GodwinYeboah.CoursePlatformBelt.Services.CourseService;
import com.GodwinYeboah.CoursePlatformBelt.Services.UserService;
@Controller
@RequestMapping("/")
public class UserController {
    private UserService uS;
    private CourseService cS;
    private  HttpSession session;
public UserController(UserService us, CourseService cs,  HttpSession session) {
    this.uS=us;
    this.cS=cs;
    this.session = session;
  
}
@RequestMapping("/")
public String index(@ModelAttribute("user") User user) {
//   null to begin with 
	uS.logout(session);
    return "index";
}
@PostMapping("/")
public String create(@Valid @ModelAttribute("user") User user, BindingResult res, RedirectAttributes flash) {
    if(res.hasErrors()) {
        flash.addFlashAttribute("errors", res.getAllErrors());
        return "redirect:/";
    }else {
        User exists = uS.findByEmail(user.getEmail());

        if(exists == null) {

            User u = uS.create(user);
            uS.login(session, u.getId());
            return "redirect:/";
        }else {
            flash.addFlashAttribute("error", "A user with this email already exists.");
            return "redirect:/";
        }
    }
}
@PostMapping("/login")
public String login(@RequestParam("email") String email, @RequestParam("password") String password, RedirectAttributes flash) {
    if(email.length()< 1) {
        flash.addFlashAttribute("error", "Email cannot be blank.");
        return "redirect:/";
    }
    User user = uS.findByEmail(email);

    if(user == null) {
        flash.addFlashAttribute("error", "No user with this email was found.");
        return "redirect:/";
    }else {
        if(uS.isMatch(password, user.getPassword())) {
            uS.login(session, user.getId());
            return "redirect:/courses";
        }else {
            flash.addFlashAttribute("error", "Invalid Credentials");
            return"redirect:/";
        }
    }
}
@RequestMapping("/courses")
public String dashboard(Model model, HttpSession s) {
    ArrayList <Course>courses = cS.all();
   
    User user = uS.find((long) s.getAttribute("id"));
    model.addAttribute("newUser", user);
    model.addAttribute("courses", courses);
    return "dashboard";
	}

@RequestMapping("/courses/new")
public String createNewCourse( Model model, HttpSession s,@Valid  @ModelAttribute("Course") Course course, BindingResult res ) {
	if(res.hasErrors()) {
	    return "edit";
	}
	
	
    return "edit";
	}

@PostMapping("/courses/new")
public String addNewCourse(Model model, HttpSession s,@Valid  @ModelAttribute("Course") Course course,BindingResult res) {
	if(res.hasErrors()) {
	    return "edit";
	}
		cS.create(course);
    return "redirect:/courses";
	}

@RequestMapping("/courses/{id}")
public String editById(@PathVariable("id") Long id, Model model , HttpSession s) {
	
//		
	
	model.addAttribute("userID", uS.find((long) s.getAttribute("id")));
	
	model.addAttribute("userCourse", cS.find(id));

    return "editById";
	}

@RequestMapping("/add/{course_id}")
public String addById(@PathVariable("course_id") Long id, Model model ,HttpSession s ) {

	User user = uS.find((long) s.getAttribute("id"));
	Course course = cS.find(id);
	user.getCourses().add(course);
	uS.update(user);
    return "redirect:/courses";
	}

@RequestMapping("/delete/{delete_id}")
	public String delete(@PathVariable("delete_id") Long id){
	uS.destroy(id);
	return "redirect:/";
}

}